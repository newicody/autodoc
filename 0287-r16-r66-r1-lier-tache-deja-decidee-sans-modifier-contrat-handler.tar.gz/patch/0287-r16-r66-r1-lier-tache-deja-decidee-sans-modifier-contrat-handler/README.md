# 0287 r16-r66-r1 — tâche déjà décidée sans modification du contrat handler

## Base attendue

- commit : `578393f`
- unité précédente : `0287-r16-r65-implementer-continuation-postgresql-et-step-runner-transactionnel`

## Correction

La première version r16-r66 modifiait `scheduler_handler_contract.py` afin de
rendre `HandlerInformationSink` utilisable avec `isinstance`. Ce hunk était
fragile et n'est pas nécessaire à la responsabilité de la frontière.

Cette révision :

- ne modifie plus le contrat canonique du handler ;
- vérifie structurellement la méthode `publish` dans r65 et r66 ;
- ajoute la frontière complète de réhydratation d'une tâche déjà choisie ;
- réutilise le catalogue et la fabrique explicite des dix handlers ;
- ne crée aucun Scheduler, routeur, Dispatcher, EventBus ou backend.

## Application

```bash
python apply_patch_queue.py \
  --patch 0287-r16-r66-r1-lier-tache-deja-decidee-sans-modifier-contrat-handler \
  --commit \
  --push \
  --allow-dirty
```

Ne pas appliquer auparavant la première version r16-r66 ayant échoué.
